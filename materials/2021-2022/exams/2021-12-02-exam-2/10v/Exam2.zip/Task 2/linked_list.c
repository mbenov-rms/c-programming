#include <stdlib.h>

#include "linked_list.h"

struct node_t* add(struct node_t *head, int value) {
  struct node_t* new_node = malloc(sizeof(struct node_t));
  new_node->next = NULL;
  new_node->value = value;

  if(head == NULL) {
    return new_node;
  }

  struct node_t* curr = head;
  while(curr->next != NULL) curr = curr->next;

  curr->next = new_node;
  return head;
}
