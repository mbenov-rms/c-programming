#ifndef BINARY_TREE_H
#define BINARY_TREE_H

struct node_t {
    int value;
    struct node_t* left;
    struct node_t* right;
};

struct node_t* add(struct node_t* tree, int value);

#endif
