#include <stdlib.h>

#include "bin_tree.h"

struct node_t* add(struct node_t* tree, int value) {
  if (tree == NULL) {
    struct node_t* new_node = malloc(sizeof(struct node_t));
    new_node->data = data;
    new_node->left = new_node->right = NULL;

    return new_node;
  }

  if (data < tree->data) {
    tree->left = add(tree->left, data);
  }
  else if (data > tree->data) {
    tree->right = add(tree->right, data);
  }

  return tree;
}
